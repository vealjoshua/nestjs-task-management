import { ConflictException, InternalServerErrorException } from "@nestjs/common";
import { ErrorCodes } from "../config/error-codes.enum";
import { EntityRepository, Repository } from "typeorm";
import { AuthCredentialsDto } from "./dto/auth-credentials.dto";
import { User } from "./user.entity";
import * as bcrypt from 'bcrypt'

@EntityRepository(User)
export class UserRepository extends Repository<User> {
    async signUp(authCredentialsDto: AuthCredentialsDto) {
        const { username, password } = authCredentialsDto

        const user = this.create()
        const salt = await bcrypt.genSalt()

        user.username = username
        user.password = await bcrypt.hash(password, salt)
        user.salt = salt

        try {
            await user.save()
        } catch (error) {
            switch (error.code) {
                case ErrorCodes.DUPLICATE_EXISTS:
                    throw new ConflictException('Username already exists')            
                default:
                    throw new InternalServerErrorException()
            }
        }
    }

    async validateUserPassword(authCredentialsDto: AuthCredentialsDto): Promise<string> {
        const { username, password } = authCredentialsDto
        const user = await this.findOne({ username })

        if (user && await user.validatePassword(password)) {
            return user.username
        }

        return null
    }
}
