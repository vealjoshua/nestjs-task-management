export enum ErrorCodes {
    DUPLICATE_EXISTS = '23505'
}